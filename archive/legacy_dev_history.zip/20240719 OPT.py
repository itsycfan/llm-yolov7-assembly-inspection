# 建立虚拟环境，环境名：hrcreading
# PS C:\Users\Tesisti> python -m venv hrcreading
# PS C:\Users\Tesisti> .\hrcreading\Scripts\activate
# (hrcreading) PS C:\Users\Tesisti> C:/Python310/python.exe c:/Users/Tesisti/AppData/Local/Temp/Reading_CaseStudy_3.py

# 在环境中写入GPT的API
# $env:OPENAI_API_KEY = "sk-proj-5TX9ug0B6qDGBHHPTzqzT3BlbkFJDqqZnPh7HjYkSIwuRGDw"
# $env:OPENAI_API_KEY

import os
import sys
import time
from datetime import datetime
import cv2
import torch
import numpy as np
import pandas as pd
import tkinter as tk
from tkinter import ttk, messagebox
from PIL import Image, ImageTk
import matplotlib
matplotlib.use('Agg')  # 在导入pyplot之前设置backend
import matplotlib.pyplot as plt
import pygame
from playsound import playsound
import pyttsx3
import requests
import openai
from IPython.display import display, Audio
from tkinter import simpledialog
import torch.nn.functional as F
import torch
from ultralytics import YOLO
import yolov7
import torchvision

# 配置管理
CONFIG = {
    'yolov7_path': 'C:/Users/Tesisti/Desktop/Yuchen 2023-2026/06 GPT+YOLOV7/yolov7',
    'weights_path': 'C:/Users/Tesisti/Desktop/Yuchen 2023-2026/06 GPT+YOLOV7/yolov7/best.pt',
    'assembly_tasks_path': 'C:/Users/Tesisti/Desktop/Yuchen 2023-2026/06 GPT+YOLOV7/assembly_tasks.xlsx',
    'error_templates_path': 'C:/Users/Tesisti/Desktop/Yuchen 2023-2026/06 GPT+YOLOV7/error_templates.xlsx',
    'gpt_prompt_path': 'C:/Users/Tesisti/Desktop/Yuchen 2023-2026/06 GPT+YOLOV7/gpt_prompt.xlsx',
    'instruction_path': 'C:/Users/Tesisti/Desktop/Yuchen 2023-2026/06 GPT+YOLOV7/CS_CIRP2024/',
    'results_image_dir': 'C:/Users/Tesisti/Desktop/Yuchen 2023-2026/06 GPT+YOLOV7/Results_Image',
    'results_text_dir': 'C:/Users/Tesisti/Desktop/Yuchen 2023-2026/06 GPT+YOLOV7/Results_Text',
    'results_errorlog_dir': 'C:/Users/Tesisti/Desktop/Yuchen 2023-2026/06 GPT+YOLOV7/Results_ErrorLog',
    'results_speech_dir': 'C:/Users/Tesisti/Desktop/Yuchen 2023-2026/06 GPT+YOLOV7/Results_Speech',
    'TTS_speech_dir': 'C:/Users/Tesisti/Desktop/Yuchen 2023-2026/06 GPT+YOLOV7/TTS_Speech',
    'tts_voice': 'alloy'
}

class AssemblyMonitoringSystem():
    def __init__(self, window): # 全系统初始化
        self.window = window
        self.initialize_gui()
        self.operator_name = self.get_operator_name()
        self.load_data()
        self.initialize_model()
        self.yolov7_label_order = ['Allen key', 'Hex cap screw (big)', 'Drive shaft companion flange', 'Nuts', 'Pump housing', 'S12', 'S6', 'S9', 'Washers', 'Wrench size 13']
    
    def load_data(self): # 加载数据：1)装配任务，2)错误模板，3)GPT prompt模板.
        self.assembly_tasks_df = pd.read_excel(CONFIG['assembly_tasks_path'])
        self.error_templates_df = pd.read_excel(CONFIG['error_templates_path'])
        self.gpt_prompt_df = pd.read_excel(CONFIG['gpt_prompt_path'])
        self.error_templates = dict(zip(self.error_templates_df['error_type'], self.error_templates_df['template']))

    def initialize_model(self): # 初始化 YOLOv7 模型
        # self.device = torch.device('cuda' if torch.cuda.is_available() else 'cpu')
        self.device = torch.device('cpu')
        self.model = torch.hub.load(CONFIG['yolov7_path'], 'custom', CONFIG['weights_path'], source='local').to(self.device)
        self.model.eval()

    def get_operator_name(self): # 获取操作者名字
        name = simpledialog.askstring("Input", "Please enter the operator's name:", parent=self.window)
        return name if name else "Unknown Operator"

    def initialize_gui(self): # GUI初始化
        # 创建 GUI 元素
        self.window.title("Assembly Monitoring System")
        self.window.geometry("1400x900")
        pygame.mixer.init()

        # 创建左右列
        self.left_column = tk.Frame(self.window, width=800, bg='white')
        self.right_column = tk.Frame(self.window, width=600, bg='light gray')
        self.left_column.pack(side='left', fill='both', expand=True)
        self.right_column.pack(side='right', fill='both', expand=True)

        # 创建左列的子框架
        self.image_display_frame = tk.Frame(self.left_column, width=800)
        label_description_0 = tk.Label(self.image_display_frame, text="Multi-form Instructions", font=('Arial', 16, 'bold'))
        label_description_0.pack(pady=(20, 0))
        self.image_display_frame.pack(side="top", fill="both", expand=True)
        self.command_frame = tk.Frame(self.left_column, width=400)
        self.command_frame.pack(side="top", fill="both", expand=False)

        # 创建左列图像显示区域
        self.left_image_frame = tk.Frame(self.image_display_frame, width=400)
        self.right_image_frame = tk.Frame(self.image_display_frame, width=400)
        self.left_image_frame.pack(side="left", fill="both", expand=True)
        self.right_image_frame.pack(side="right", fill="both", expand=True)

        self.canvas_com = tk.Canvas(self.left_image_frame, bg="gray", height=80, width=80)
        self.label_description_1 = tk.Label(self.left_image_frame, text="Component", font=('Arial', 14))
        self.label_description_1.pack(pady=(20, 0))
        self.canvas_com.pack(pady=(5, 5), fill="both", expand=True)

        self.canvas_ope = tk.Canvas(self.left_image_frame, bg="gray", height=80, width=80)
        self.label_operation_1 = tk.Label(self.left_image_frame, text="Operation", font=('Arial', 14))
        self.label_operation_1.pack(pady=(5, 0))
        self.canvas_ope.pack(pady=(5, 20), fill="both", expand=True)

        self.canvas_too = tk.Canvas(self.right_image_frame, bg="gray", height=80, width=80)
        self.label_description_2 = tk.Label(self.right_image_frame, text="Tool", font=('Arial', 14))
        self.label_description_2.pack(pady=(20, 0))
        self.canvas_too.pack(pady=(5, 5), fill="both", expand=True)

        self.canvas_res = tk.Canvas(self.right_image_frame, bg="gray", height=80, width=80)
        self.label_operation_2 = tk.Label(self.right_image_frame, text="Assembly Result", font=('Arial', 14))
        self.label_operation_2.pack(pady=(5, 0))
        self.canvas_res.pack(pady=(5, 20), fill="both", expand=True)

        self.text_frame = tk.Frame(self.left_column, width=400)
        self.text_frame.pack(side="top", fill="both", expand=False, pady=(0, 0))
        self.text_instruction = tk.Text(self.text_frame, height=10, width=80)
        self.text_instruction.config(font=('Arial', 12))
        self.text_instruction.pack(pady=(5, 5), padx=0)

        self.command_frame = tk.Frame(self.left_column, bg='white')
        self.command_frame.pack(fill="x")

        self.controls_frame = tk.Frame(self.command_frame)
        self.controls_frame.pack(fill="x", expand=True)

        self.play_button = tk.Button(self.controls_frame, text="Play Instructions", font=('Arial', 12), command=lambda: self.audio_control('load_and_play', None))
        self.pause_button = tk.Button(self.controls_frame, text="Pause Instructions", font=('Arial', 12), command=lambda: self.audio_control('pause'))
        self.volume_control = tk.Scale(self.controls_frame, from_=0, to=100, orient="horizontal", label="Volume", font=('Arial', 12), command=lambda x: self.audio_control('set_volume', x))
        self.sound_type = ttk.Combobox(self.controls_frame, values=["alloy", "echo", "fable", "onyx", "nova", "shimmer"], font=('Arial', 12), state="readonly")
        self.sound_type.set("alloy")
        self.play_button.grid(row=0, column=0, padx=20, pady=10, sticky="ew")
        self.pause_button.grid(row=0, column=1, padx=20, pady=10, sticky="ew")
        self.volume_control.grid(row=0, column=2, padx=20, pady=10, sticky="ew")
        self.sound_type.grid(row=0, column=3, padx=20, pady=10, sticky="ew")

        # 创建右列的子框架
        self.realtime_image_frame = tk.Frame(self.right_column, width=400, bg='light blue')
        self.realtime_image_frame.pack(side="top", fill="both", expand=True)
        label_description_3 = tk.Label(self.realtime_image_frame, text="Actual Statu", font=('Arial', 16, 'bold'), bg='light blue')
        label_description_3.pack(pady=(20, 0))

        label_description_realtime = tk.Label(self.realtime_image_frame, text="Real-time Image", font=('Arial', 14), bg='light blue')
        self.realtime_canvas = tk.Canvas(self.realtime_image_frame, bg="gray", height=400, width=550)
        label_description_realtime.pack(pady=(20, 0))
        self.realtime_canvas.pack(pady=(5, 5), fill="none", expand=False)

        self.progress_frame = tk.Frame(self.right_column, width=400, bg='light blue')
        self.progress_frame.pack(side="top", fill="both", expand=False, pady=(0, 0))
        progress_label = tk.Label(self.progress_frame, text="Assembly Status", font=('Arial', 14), bg='light blue')
        progress_label.pack()
        self.progress_text = tk.Text(self.progress_frame, height=13, width=56)
        self.progress_text.config(font=('Arial', 12))
        self.progress_text.pack(pady=(5, 20), padx=20)

        self.button_frame = tk.Frame(self.right_column, bg='light blue', height=40)
        self.button_frame.pack(side='bottom', fill='x', expand=False)
        self.exit_button = tk.Button(self.button_frame, text="Exit", font=('Arial', 12), command=self.window.destroy, width=10)
        self.error_button = tk.Button(self.button_frame, text="Report Error", font=('Arial', 12), command=lambda: messagebox.showerror("Error", "System Error Reported"), width=20)
        self.exit_button.pack(side="left", padx=35, pady=25)
        self.error_button.pack(side="right", padx=35, pady=25)

    def play_audio(self, filename): # 播放音频
        if filename and os.path.exists(filename):
            try:
                pygame.mixer.music.load(filename)
                pygame.mixer.music.play()
                while pygame.mixer.music.get_busy():
                    pygame.time.Clock().tick(10)
            except Exception as e:
                print(f"Error playing audio: {e}")
                # 如果播放失败，可以尝试使用其他方法播放，或者跳过
        else:
            print(f"Audio file not found: {filename}")

    def update_gui_4image(self, step): # 更新四个图像显示区域
        image_paths = {
            'component': f'{CONFIG["instruction_path"]}/component/step{step}_com.png',
            'tool': f'{CONFIG["instruction_path"]}/tool/step{step}_too.png',
            'operation': f'{CONFIG["instruction_path"]}/operation/step{step}_ope.png',
            'result': f'{CONFIG["instruction_path"]}/result/step{step}_res.png'
        }
        canvases = {
            'component': self.canvas_com,
            'tool': self.canvas_too,
            'operation': self.canvas_ope,
            'result': self.canvas_res
        }
        for key, path in image_paths.items():
            canvas = canvases[key]
            if os.path.exists(path):
                img = Image.open(path)
                img = img.resize((canvas.winfo_width(), canvas.winfo_height()), Image.Resampling.LANCZOS)
                img = ImageTk.PhotoImage(img)
                canvas.image = img
                canvas.create_image(0, 0, anchor='nw', image=img)
            else:
                canvas.delete("all")
        self.window.update()
    
    def update_realtime_image(self, image): # 更新实时图像显示区域
        try:
            if isinstance(image, torch.Tensor):
                image = self.postprocess_image(image)
            
            if isinstance(image, np.ndarray):
                # 确保图像是 RGB 格式
                if image.shape[2] == 3:
                    image_rgb = cv2.cvtColor(image, cv2.COLOR_BGR2RGB)
                else:
                    image_rgb = image
                image_pil = Image.fromarray(image_rgb)
            elif isinstance(image, Image.Image):
                image_pil = image
            else:
                print(f"Unexpected image type: {type(image)}")
                return

            # 调整图像大小
            resized_image = image_pil.resize((self.realtime_canvas.winfo_width(), self.realtime_canvas.winfo_height()), Image.Resampling.LANCZOS)
            
            photo_image = ImageTk.PhotoImage(resized_image)
            
            self.realtime_canvas.delete("all")  # 清除旧的图像
            self.realtime_canvas.image = photo_image  # 保持对图像的引用
            self.realtime_canvas.create_image(0, 0, anchor='nw', image=photo_image)
            
            self.window.update()
        except Exception as e:
            print(f"Error updating realtime image: {e}")

    def update_instruction_text(self, text): # 更新指令显示的文字区域
        self.text_instruction.delete('1.0', tk.END)
        self.text_instruction.insert(tk.END, text)

    def update_progress_text(self, text): # 更新进度显示的文字区域
        self.progress_text.insert(tk.END, text)

    def audio_control(self, action, value=None): # 控制音频（播放，暂停，调整音量）
        if action == 'load_and_play':
            try:
                playsound(value)
            except Exception as e:
                print(f"Error playing {value}: {e}")
        elif action == 'pause':
            pygame.mixer.music.pause()
        elif action == 'set_volume':
            volume_level = float(value) / 100
            pygame.mixer.music.set_volume(volume_level)

    def capture_image(self): # 捕捉实时图像
        cap = cv2.VideoCapture(0)
        ret, frame = cap.read()
        cap.release()
        if ret:
            return frame  # 返回原始图像，不进行预处理
        else:
            print("Failed to capture image")
            return None

    def preprocess_image(self, frame): 
        try:
            if frame is None:
                print("Input frame is None")
                return None
            img = cv2.cvtColor(frame, cv2.COLOR_BGR2RGB)
            img = img.astype(np.float32) / 255.0
            img = np.transpose(img, (2, 0, 1))
            img = np.expand_dims(img, 0)
            img = torch.from_numpy(img).float()
            return img
        except Exception as e:
            print(f"Error during image preprocessing: {e}")
            return None

    def postprocess_image(self, tensor): # 将模型输出的PyTorch张量转换回可以显示或进一步处理的NumPy数组
        if isinstance(tensor, torch.Tensor):
            tensor = tensor.cpu()
            image_np = tensor.numpy()
            image_np = image_np[0]
            if image_np.shape[0] < image_np.shape[2]:
                image_np = image_np.transpose(1, 2, 0)
            if image_np.max() <= 1.0:
                image_np = (image_np * 255).astype(np.uint8)
            return image_np
        elif isinstance(tensor, np.ndarray):
            return tensor  # 如果已经是numpy数组，直接返回
        else:
            print(f"Unexpected data type in postprocess_image: {type(tensor)}")
            return None

    def enhance_image(self, image): # 增强图像的亮度和饱和度
        # 转换到 HSV 色彩空间
        hsv = cv2.cvtColor(image, cv2.COLOR_BGR2HSV).astype("float32")
        (h, s, v) = cv2.split(hsv)

        # 增加亮度
        v = v * 1.4  # 增加 20% 的亮度
        v = np.clip(v, 0, 255)

        # 增加饱和度
        s = s * 1.3  # 增加 30% 的饱和度
        s = np.clip(s, 0, 255)

        # 合并通道
        hsv = cv2.merge([h, s, v])

        # 转换回 BGR 色彩空间
        enhanced_image = cv2.cvtColor(hsv.astype("uint8"), cv2.COLOR_HSV2BGR)

        return enhanced_image

    def detect_items(self, image): # YOLOv7检测
        if image is None:
            print("Input image is None")
            return []

        with torch.no_grad():
            predictions = self.model(image)  # 使用模型进行预测
            predictions = predictions[0] if isinstance(predictions, tuple) else predictions
            predictions = self.non_max_suppression(predictions, conf_thres=0.6, iou_thres=0.45)

        detected_items = []  # 初始化检测到的物体列表

        # 检查predictions是否存在且不为空
        if predictions is not None and len(predictions) > 0 and len(predictions[0]) > 0:
            detected_items = predictions[0].cpu().numpy()  # 提取检测到的物体并转换为numpy数组
            print(f"YOLOv7 detections found: {len(detected_items)}")  # 打印检测到的物体数量
            
            for det in detected_items:
                x1, y1, x2, y2, conf, cls = det
                print(f"Detected {self.yolov7_label_order[int(cls)]} with confidence {conf:.2f} at location [{x1:.1f}, {y1:.1f}, {x2:.1f}, {y2:.1f}]")
        else:
            print("No detections found.")

        return detected_items

    def non_max_suppression(self, prediction, conf_thres=0.25, iou_thres=0.7, classes=None, agnostic=False, multi_label=False, labels=()): # 去除冗余的检测框
        """Runs Non-Maximum Suppression (NMS) on inference results

        Returns:
            list of detections, on (n,6) tensor per image [xyxy, conf, cls]
        """

        nc = prediction.shape[2] - 5  # number of classes
        xc = prediction[..., 4] > conf_thres  # candidates

        # Settings
        min_wh, max_wh = 2, 4096  # (pixels) minimum and maximum box width and height
        max_det = 300  # maximum number of detections per image
        max_nms = 30000  # maximum number of boxes into torchvision.ops.nms()
        time_limit = 10.0  # seconds to quit after
        redundant = True  # require redundant detections
        multi_label &= nc > 1  # multiple labels per box (adds 0.5ms/img)
        merge = False  # use merge-NMS

        t = time.time()
        output = [torch.zeros((0, 6), device=prediction.device)] * prediction.shape[0]
        for xi, x in enumerate(prediction):  # image index, image inference
            # Apply constraints
            # x[((x[..., 2:4] < min_wh) | (x[..., 2:4] > max_wh)).any(1), 4] = 0  # width-height
            x = x[xc[xi]]  # confidence

            # Cat apriori labels if autolabelling
            if labels and len(labels[xi]):
                l = labels[xi]
                v = torch.zeros((len(l), nc + 5), device=x.device)
                v[:, :4] = l[:, 1:5]  # box
                v[:, 4] = 1.0  # conf
                v[range(len(l)), l[:, 0].long() + 5] = 1.0  # cls
                x = torch.cat((x, v), 0)

            # If none remain process next image
            if not x.shape[0]:
                continue

            # Compute conf
            if nc == 1:
                x[:, 5:] = x[:, 4:5] # for models with one class, cls_loss is 0 and cls_conf is always 0.5,
                                    # so there is no need to multiplicate.
            else:
                x[:, 5:] *= x[:, 4:5]  # conf = obj_conf * cls_conf

            # Box (center x, center y, width, height) to (x1, y1, x2, y2)
            box = self.xywh2xyxy(x[:, :4])

            # Detections matrix nx6 (xyxy, conf, cls)
            if multi_label:
                i, j = (x[:, 5:] > conf_thres).nonzero(as_tuple=False).T
                x = torch.cat((box[i], x[i, j + 5, None], j[:, None].float()), 1)
            else:  # best class only
                conf, j = x[:, 5:].max(1, keepdim=True)
                x = torch.cat((box, conf, j.float()), 1)[conf.view(-1) > conf_thres]

            # Filter by class
            if classes is not None:
                x = x[(x[:, 5:6] == torch.tensor(classes, device=x.device)).any(1)]

            # Apply finite constraint
            # if not torch.isfinite(x).all():
            #     x = x[torch.isfinite(x).all(1)]

            # Check shape
            n = x.shape[0]  # number of boxes
            if not n:  # no boxes
                continue
            elif n > max_nms:  # excess boxes
                x = x[x[:, 4].argsort(descending=True)[:max_nms]]  # sort by confidence

            # Batched NMS
            c = x[:, 5:6] * (0 if agnostic else max_wh)  # classes
            boxes, scores = x[:, :4] + c, x[:, 4]  # boxes (offset by class), scores
            i = torchvision.ops.nms(boxes, scores, iou_thres)  # NMS
            if i.shape[0] > max_det:  # limit detections
                i = i[:max_det]
            if merge and (1 < n < 3E3):  # Merge NMS (boxes merged using weighted mean)
                # update boxes as boxes(i,4) = weights(i,n) * boxes(n,4)
                iou = box_iou(boxes[i], boxes) > iou_thres  # iou matrix
                weights = iou * scores[None]  # box weights
                x[i, :4] = torch.mm(weights, x[:, :4]).float() / weights.sum(1, keepdim=True)  # merged boxes
                if redundant:
                    i = i[iou.sum(1) > 1]  # require redundancy

            output[xi] = x[i]
            if (time.time() - t) > time_limit:
                print(f'WARNING: NMS time limit {time_limit}s exceeded')
                break  # time limit exceeded

        return output

    def xywh2xyxy(self, x): # 坐标格式转换函数, 用于NMS
        # Convert nx4 boxes from [x, y, w, h] to [x1, y1, x2, y2] where xy1=top-left, xy2=bottom-right
        y = x.clone() if isinstance(x, torch.Tensor) else np.copy(x)
        y[:, 0] = x[:, 0] - x[:, 2] / 2  # top left x
        y[:, 1] = x[:, 1] - x[:, 3] / 2  # top left y
        y[:, 2] = x[:, 0] + x[:, 2] / 2  # bottom right x
        y[:, 3] = x[:, 1] + x[:, 3] / 2  # bottom right y
        return y

    def classify_detections(self, detected):  # 把YOLOv7模型检测出来的物体进行分类
        classified_items = {
            'components': [],
            'tools': [],
            'steps': []
        }

        for detection in detected:
            x1, y1, x2, y2, conf, cls = detection[:6]
            if conf > 0.5:
                detected_label = self.yolov7_label_order[int(cls)]
                print('Detected label:', detected_label)

                # 检查步骤
                if any(detected_label in step for step in self.steps_classes.values()):
                    classified_items['steps'].append(detected_label)
                    print(f'Matched to step: {detected_label}')

                # 检查组件
                elif any(detected_label in component for component in self.components_classes.values()):
                    classified_items['components'].append(detected_label)
                    print(f'Matched to component: {detected_label}')

                # 检查工具
                elif any(detected_label in tool for tool in self.tools_classes.values()):
                    classified_items['tools'].append(detected_label)
                    print(f'Matched to tool: {detected_label}')

                else:
                    print(f'Warning: No match found for {detected_label}')

        print(f"Classified items: {classified_items}")
        return classified_items

    def error_validation(self, classified, step_details, operator_name, location, item_type, task): # 检查分类后的物体是否存在错误，并生成错误日志
        details = {
            'now': datetime.now().strftime("%Y-%m-%d %H:%M"),
            'operator_name': self.operator_name,
            'location': location,
            'expected': step_details[item_type],
            'actual': classified[item_type],
            'step': step_details['step'],
            'task': task
        }

        error_result = {
            'type': item_type,
            'specific': details['actual'],
            'result': True
        }

        # 修改这里的比较逻辑
        expected_set = set(item.split(',')[0] for item in details['expected'].split(';'))
        actual_set = set(details['actual'])

        if actual_set.issubset(expected_set):
            error_result['result'] = True
            error_log = None
        else:
            error_result['result'] = False
            error_log = self.error_templates[item_type].format(**details)

            errorLog_dir = CONFIG['results_errorlog_dir']
            current_time = datetime.now().strftime("%Y-%m-%d_%H-%M-%S")
            errorLog_filename = f"{errorLog_dir}/text{current_time}.txt"
            with open(errorLog_filename, "w") as text_file:
                text_file.write(error_log)
            print(f"Error log saved.")

        return error_result, error_log

    def annotate_image_with_labels(self, image, detected_items, classified_items, item_type, error_result): # 根据错误情况来对实时图像中存在的所有物体进行标记
        # 注意：OpenCV 使用 BGR 颜色空间
        correct_color = (0, 255, 0)  # 绿色
        wrong_color = (0, 0, 255)    # 红色
        neutral_color = (128, 128, 128)  # 灰色

        processed_image = self.postprocess_image(image)
        if processed_image is None:
            print("Failed to process image for annotation")
            return None

        if detected_items is None or (isinstance(detected_items, np.ndarray) and detected_items.size == 0):
            print("No items detected for annotation")
            return processed_image

        print(f"Annotating for item_type: {item_type}")
        print(f"Classified items: {classified_items}")
        print(f"Error result: {error_result}")

        for detection in detected_items:
            x1, y1, x2, y2, conf, cls = detection[:6]
            detection_label = self.yolov7_label_order[int(cls)]

            print(f"Processing detection: {detection_label}")
            # 修改这里的逻辑
            if any(detection_label in item for item in classified_items[item_type]):
                color = correct_color if error_result['result'] else wrong_color
                print(f"  - In classified items, color: {color}")
            else:
                color = neutral_color
                print(f"  - Not in classified items, color: {color}")

            cv2.rectangle(processed_image, (int(x1), int(y1)), (int(x2), int(y2)), color, 2)
            cv2.putText(processed_image, detection_label, (int(x1), int(y1) - 10), cv2.FONT_HERSHEY_SIMPLEX, 0.5, color, 2)

        # 提高亮度和饱和度
        processed_image = self.enhance_image(processed_image)

        # 转换颜色空间从 BGR 到 RGB
        processed_image = cv2.cvtColor(processed_image, cv2.COLOR_BGR2RGB)

        timestamp = datetime.now().strftime("%Y%m%d%H%M%S")
        annotated_image_path = f'{CONFIG["results_image_dir"]}/annotated_{item_type}_{timestamp}.jpg'
        try:
            os.makedirs(os.path.dirname(annotated_image_path), exist_ok=True)
            success = cv2.imwrite(annotated_image_path, processed_image)
            if success:
                print(f"Annotated image saved to {annotated_image_path}")
            else:
                print(f"Failed to save annotated image: cv2.imwrite returned False")
        except Exception as e:
            print(f"Failed to save annotated image: {str(e)}")

        return processed_image

    def generate_prompt(self, step_details, error_description): # 获取将要传给GPT的prompt模板
        prompt_template = self.gpt_prompt_df['prompt'].iloc[0]
        prompt = prompt_template.format(step_details=step_details, error_description=error_description)
        return prompt

    def gpt_tts(self, prompt): # 利用GPT生成语音提醒，输出语音地址
        api_key = os.getenv('OPENAI_API_KEY')
        if not api_key:
            raise ValueError("API key is not set. Please ensure the 'OPENAI_API_KEY' environment variable is defined.")

        response = openai.chat.completions.create(
            model="gpt-4o",
            messages=[{"role": "user", "content": prompt}]
        )
        text = response.choices[0].message.content.strip()

        results_text_dir = CONFIG['results_text_dir']
        current_time = datetime.now().strftime("%Y-%m-%d_%H-%M-%S")
        text_filename = f"{results_text_dir}/text{current_time}.txt"
        with open(text_filename, "w") as text_file:
            text_file.write(text)
        print(f"Results text saved.")

        headers = {
            'Authorization': f'Bearer {api_key}',
            'Content-Type': 'application/json',
        }
        data = {
            "model": "tts-1",
            "input": text,
            "voice": CONFIG['tts_voice']
        }
        response = requests.post('https://api.openai.com/v1/audio/speech', headers=headers, json=data)
        if response.status_code == 200:
            speech_filename = f"{CONFIG['results_speech_dir']}/speech{current_time}.mp3"
            with open(speech_filename, 'wb') as file:
                file.write(response.content)
            print("Error instruction speech saved.")
            return speech_filename
        else:
            print("Failed to generate speech:", response.status_code, response.text)
            return None

    def text_to_speech(self, text): # 把除了GPT以外的文字转换成语音，输出语音地址
        timestamp = datetime.now().strftime("%Y%m%d%H%M%S")
        voice_path = f'{CONFIG["TTS_speech_dir"]}/voice_{timestamp}.mp3'
        try:
            engine = pyttsx3.init()
            rate = engine.getProperty('rate')
            engine.setProperty('rate', rate - 80)
            volume = engine.getProperty('volume')
            engine.setProperty('volume', volume + 0.25)
            voices = engine.getProperty('voices')
            engine.setProperty('voice', voices[0].id)
            engine.say(text)
            engine.save_to_file(text, voice_path)
            engine.runAndWait()
            return voice_path
        except Exception as e:
            print(f"Error with text-to-speech: {e}")
            return None

    def get_step_details(self, index): # 从预先加载的装配任务数据中提取特定步骤的详细信息。
        self.steps_classes = self.assembly_tasks_df['step'].dropna().to_dict()
        self.components_classes = self.assembly_tasks_df['components'].dropna().to_dict()
        self.tools_classes = self.assembly_tasks_df['tools'].dropna().to_dict()
        self.operations_classes = self.assembly_tasks_df['operations'].dropna().to_dict()
        self.time_classes = self.assembly_tasks_df['time'].dropna().to_dict()
        self.lastorder_classes = self.assembly_tasks_df['lastorder'].dropna().to_dict()
        return {
            'components': self.components_classes[index],
            'tools': self.tools_classes[index],
            'operations': self.operations_classes[index],
            'time': self.time_classes[index],
            'step': self.steps_classes[index],
            'steps': self.steps_classes[index]
        }

    def process_step(self, index, item_type, step_details): # 装配步骤的推进
        self.progress_text.delete('1.0', tk.END)
        text = f"Start assembly step{index+1}.{item_type}."
        self.update_progress_text(text + "\n")
        
        if step_details[item_type] != "None":
            retry = True
            retry_count = 0
            while retry and retry_count < 3:
                success = self.handle_step(index, item_type, step_details)
                if not success:
                    if retry_count < 2:
                        self.handle_error(index, item_type, step_details)
                        retry_count += 1
                    else:
                        self.update_progress_text("\nFailed to correct the error after 2 attempts.\n")
                        retry = False
                else:
                    success_text = "\nYou did it correctly. Now let's proceed to the next step.\n"
                    self.update_progress_text(success_text)
                    voice_path = self.text_to_speech(success_text)
                    if voice_path:
                        self.play_audio(voice_path)
                    self.update_progress_text(f"\nEnd step{index+1}.{item_type}\n")
                    retry = False
        
        self.window.update()

    def handle_step(self, index, item_type, step_details): # 区分操作类型，然后开展细分任务
        if item_type in ['components', 'tools']:
            task = f"Please prepare the following {item_type}: {step_details[item_type]}."
            sleep_time = 4
        else:
            task = f"Please follow the instructions to complete the step: {step_details['operations']}."
            sleep_time = step_details['time']

        self.update_instruction_text(task)
        self.window.update()
        time.sleep(0.1)

        voice_path = self.text_to_speech(task)
        if voice_path:
            self.play_audio(voice_path)
        else:
            print("Failed to generate speech for task")

        time.sleep(sleep_time)

        image = self.capture_image()
        if image is not None:
            self.update_realtime_image(image)
            self.window.update()
            time.sleep(0.1)

            preprocessed_image = self.preprocess_image(image)
            if preprocessed_image is not None:
                detected_items = self.detect_items(preprocessed_image)
                if detected_items is not None and len(detected_items) > 0:
                    classified_items = self.classify_detections(detected_items)

                    text = "\nDetected items:\n"
                    for det in detected_items:
                        x1, y1, x2, y2, conf, cls = det[:6]  # 获取坐标和类别信息
                        label = self.yolov7_label_order[int(cls)]
                        text += f"{label} (confidence: {conf:.2f}.)\n"
                    self.update_progress_text(text)
                    self.window.update()
                    time.sleep(0.1)

                    self.error_result, self.error_log = self.error_validation(
                        classified_items, step_details, self.operator_name, 'location', item_type, task
                    )

                    text = f"\nError Log: {self.error_log}."
                    self.update_progress_text(text)
                    self.window.update()
                    time.sleep(0.1)

                    annotated_image = self.annotate_image_with_labels(
                        image, detected_items, classified_items, item_type, self.error_result
                    )
                    if annotated_image is not None:
                        self.update_realtime_image(annotated_image)
                    else:
                        print("Failed to annotate image")
                    self.window.update()
                    time.sleep(0.1)
                else:
                    print("No items detected or detection failed")
                    self.update_progress_text("No items detected or detection failed.\n")
            else:
                print("Failed to preprocess image")
                self.update_progress_text("Failed to preprocess image.\n")
        else:
            print("Failed to capture image")
            self.update_progress_text("Failed to capture image.\n")

        self.window.update()
        time.sleep(0.1)  # 给GUI一些时间来刷新

        return self.error_result.get('result', False)

    def handle_error(self, index, item_type, step_details): # 装配流程中的错误处理
        prompt = self.generate_prompt(step_details, self.error_log)
        speech_filename = self.gpt_tts(prompt)
        if speech_filename:
            self.play_audio(speech_filename)
        self.play_audio(speech_filename)
        text = f"\nRedo step{index+1}.{item_type}"
        self.update_progress_text(text)

    def run(self):
        print("Starting the Assembly Monitoring System...")
        try:
            for index in range(self.assembly_tasks_df.dropna(how='all').shape[0] - 1):
                for index in range(self.assembly_tasks_df.dropna(how='all').shape[0] - 1):
                    step_details = self.get_step_details(index)
                    step_number = int(''.join(filter(str.isdigit, step_details['step'])))
                    self.update_gui_4image(step_number)
                    self.progress_text.delete('1.0', tk.END)
                    self.window.update()
                    time.sleep(0.1)
                    
                    for item_type in ['components', 'tools', 'steps']:
                        self.process_step(index, item_type, step_details)
                        self.window.update()
        except Exception as e:
            print(f"An error occurred during execution: {e}")
            import traceback
            traceback.print_exc()
        finally:
            print("Assembly Monitoring System has finished running.")


if __name__ == '__main__':
    root = tk.Tk()
    app = AssemblyMonitoringSystem(root)
    app.run()
    root.mainloop()