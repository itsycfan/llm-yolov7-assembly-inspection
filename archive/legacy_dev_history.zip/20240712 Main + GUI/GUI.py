import tkinter as tk
from tkinter import ttk, messagebox


def create_gui():
    root = tk.Tk()
    root.title("Assembly Monitoring System")
    root.geometry("1200x800")  # Adjust window size

    # Frames for different sections
    left_column = tk.Frame(root, width=800, bg='white')
    right_column = tk.Frame(root, width=400, bg='light gray')
    left_column.pack(side='left', fill='both', expand=True)
    right_column.pack(side='right', fill='both', expand=True)


    # ———————————————————————————————————————————————————————————— Left Column ————————————————————————————————————————————————————————————

    # Sub-frames within the left frame
    image_display_frame = tk.Frame(left_column, width=800)  # Expanded width for images
    label_description_0 = tk.Label(image_display_frame, text="Multi-form Instructions", font=('Arial', 14, 'bold'))
    label_description_0.pack(pady=(20, 0))
    command_frame = tk.Frame(left_column, width=400)
    image_display_frame.pack(side="top", fill="both", expand=True)
    command_frame.pack(side="top", fill="both", expand=False)

    # Sub-frames for each image and its description
    left_image_frame = tk.Frame(image_display_frame, width=400)
    right_image_frame = tk.Frame(image_display_frame, width=400)
    left_image_frame.pack(side="left", fill="both", expand=True, padx=(0, 0))  # Add padding
    right_image_frame.pack(side="right", fill="both", expand=True, padx=(0, 0))  # Add padding

    # Labels and images in the left image frame
    label_description_1 = tk.Label(left_image_frame, text="Correct Component", font=('Arial', 12))
    canvas1 = tk.Canvas(left_image_frame, bg="gray", height=80, width=80)
    label_operation_1 = tk.Label(left_image_frame, text="Correct Operation", font=('Arial', 12))
    canvas2 = tk.Canvas(left_image_frame, bg="gray", height=80, width=80)
    label_description_1.pack(pady=(20, 0))
    canvas1.pack(pady=(5, 5), fill="both", expand=True)
    label_operation_1.pack(pady=(5, 0))
    canvas2.pack(pady=(5, 20), fill="both", expand=True)

    # Labels and images in the right image frame
    label_description_2 = tk.Label(right_image_frame, text="Correct Tool", font=('Arial', 12))
    canvas3 = tk.Canvas(right_image_frame, bg="gray", height=80, width=80)
    label_operation_2 = tk.Label(right_image_frame, text="Correct Result", font=('Arial', 12))
    canvas4 = tk.Canvas(right_image_frame, bg="gray", height=80, width=80)
    label_description_2.pack(pady=(20, 0))
    canvas3.pack(pady=(5, 5), fill="both", expand=True)
    label_operation_2.pack(pady=(5, 0))
    canvas4.pack(pady=(5, 20), fill="both", expand=True)

    # Text box for instructions
    text_frame = tk.Frame(left_column, width=400)
    text_frame.pack(side="top", fill="both", expand=False, pady=(0, 0))
    text_box = tk.Text(text_frame, height=10, width=80)
    text_box.pack(pady=(5, 5), padx=0)



    # ———————————————————————————————————————————————————————————— Right Column ————————————————————————————————————————————————————————————
    # Right column single image frame
    realtime_image_frame = tk.Frame(right_column, width=400, bg='light blue')
    realtime_image_frame.pack(side="top", fill="both", expand=True)
    label_description_3 = tk.Label(realtime_image_frame, text="Detection Information", font=('Arial', 14, 'bold'), bg='light blue')
    label_description_3.pack(pady=(20, 0))

    # Image and label in the right column
    label_description_realtime = tk.Label(realtime_image_frame, text="Real-time Image", font=('Arial', 12), bg='light blue')
    realtime_canvas = tk.Canvas(realtime_image_frame, bg="gray", height=300, width=450)
    label_description_realtime.pack(pady=(20, 0))
    realtime_canvas.pack(pady=(5, 5), fill="none", expand=False)

    # Text box for assembly progress
    progress_frame = tk.Frame(right_column, width=400, bg='light blue')
    progress_frame.pack(side="top", fill="both", expand=False, pady=(0, 0))
    progress_label = tk.Label(progress_frame, text="Assembly Satus", font=('Arial', 12), bg='light blue')
    progress_label.pack()
    progress_text = tk.Text(progress_frame, height=15, width=56)
    progress_text.pack(pady=(5, 20), padx=20)

    # Main command frame for holding all control elements
    command_frame = tk.Frame(left_column, bg='white')
    command_frame.pack(fill="x")

    # Controls frame for holding buttons and sliders horizontally
    controls_frame = tk.Frame(command_frame)
    controls_frame.pack(fill="x", expand=True)

    # Buttons and controls in the command frame
    play_button = tk.Button(controls_frame, text="Play Instructions", command=lambda: print("Playing..."))
    pause_button = tk.Button(controls_frame, text="Pause Instructions", command=lambda: print("Pausing..."))
    volume_control = tk.Scale(controls_frame, from_=0, to=100, orient="horizontal", label="Volume")
    sound_type = ttk.Combobox(controls_frame, values=["Type 1", "Type 2", "Type 3"], state="readonly")
    play_button.grid(row=0, column=0, padx=10, pady=10, sticky="ew")
    pause_button.grid(row=0, column=1, padx=10, pady=10, sticky="ew")
    volume_control.grid(row=0, column=2, padx=10, pady=10, sticky="ew")
    sound_type.grid(row=0, column=3, padx=10, pady=10, sticky="ew")
    controls_frame.grid_columnconfigure(0, weight=1)
    controls_frame.grid_columnconfigure(1, weight=1)
    controls_frame.grid_columnconfigure(2, weight=1)
    controls_frame.grid_columnconfigure(3, weight=1)

    # Button frame at the bottom of left_column
    button_frame = tk.Frame(right_column, bg='light blue')
    button_frame.pack(side='bottom', fill='x', expand=False)
    exit_button = tk.Button(button_frame, text="Exit", command=root.destroy, width=10)
    error_button = tk.Button(button_frame, text="Report Error", command=lambda: messagebox.showerror("Error", "System Error Reported"), width=20)
    exit_button.pack(side="left", padx=35, pady=25)
    error_button.pack(side="right", padx=35, pady=25)

    root.mainloop()
